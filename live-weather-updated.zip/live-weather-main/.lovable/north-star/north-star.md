<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

People know the weather right where they are, right now.

## Metric

Live weather reports shown for the visitor's location each day
