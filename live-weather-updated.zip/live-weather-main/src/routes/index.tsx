import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Live Weather — Chanakya University" },
      {
        name: "description",
        content:
          "Live weather report for Chanakya University Global Campus, Devanahalli, Bengaluru.",
      },
    ],
    links: [
      {
        rel: "icon",
        type: "image/svg+xml",
        href: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ccircle cx='44' cy='42' r='24' fill='%23ffd15c'/%3E%3Cpath d='M28 72h46a16 16 0 0 0 0-32 15 15 0 0 0-14-10 22 22 0 0 0-22 18A14 14 0 0 0 28 72z' fill='%23fff'/%3E%3C/svg%3E",
      },
    ],
  }),
  component: WeatherIndex,
});

// Chanakya University Global Campus, Devanahalli, Bengaluru
const CAMPUS = {
  lat: 13.2458,
  lon: 77.7126,
  name: "Chanakya University Global Campus",
  area: "Devanahalli, Bengaluru 562165",
};

type WeatherKind = "clear" | "partly-cloudy" | "cloudy" | "rain" | "snow" | "storm" | "fog" | "wind";
type DayPart = "day" | "afternoon" | "night";

interface HourForecast {
  time: string;
  temp: number;
  code: number;
}

interface WeatherState {
  temp: number;
  feels: number;
  code: number;
  isDay: boolean;
  wind: number;
  humidity: number;
  pressure: number;
  uv: number;
  visibility: number;
  precipProb: number;
  desc: string;
  kind: WeatherKind;
  dayPart: DayPart;
  forecast: HourForecast[];
}

const describeWeather = (code: number): { kind: WeatherKind; desc: string } => {
  if (code >= 95) return { kind: "storm", desc: "Thunderstorm" };
  if ([71, 73, 75, 77, 85, 86].includes(code)) return { kind: "snow", desc: "Snow" };
  if ([51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82].includes(code))
    return { kind: "rain", desc: "Rain" };
  if (code === 45 || code === 48) return { kind: "fog", desc: "Fog" };
  if (code === 3) return { kind: "cloudy", desc: "Overcast" };
  if (code === 1 || code === 2) return { kind: "partly-cloudy", desc: "Partly Cloudy" };
  return { kind: "clear", desc: "Clear Sky" };
};

function getDayPart(): DayPart {
  const hour = Number(
    new Intl.DateTimeFormat("en-IN", {
      timeZone: "Asia/Kolkata",
      hour: "2-digit",
      hourCycle: "h23",
    }).format(new Date()),
  );
  if (hour >= 18 || hour < 6) return "night";
  if (hour >= 12) return "afternoon";
  return "day";
}

// Approximate lunar phase from the known 2000-01-06 new moon.
// 0 = new moon, 0.25 = first quarter, 0.5 = full moon, 0.75 = last quarter.
function getMoonPhase(date = new Date()): number {
  const knownNewMoon = Date.UTC(2000, 0, 6, 18, 14);
  const synodicMonth = 29.530588853;
  const days = (date.getTime() - knownNewMoon) / 86400000;
  return ((days / synodicMonth) % 1 + 1) % 1;
}

function WeatherScene({ kind, dayPart }: { kind: WeatherKind; dayPart: DayPart }) {
  const phase = getMoonPhase();
  const isNight = dayPart === "night";
  const moonDarkX = 15 + Math.cos(phase * Math.PI * 2) * 16;
  const moonDarkRx = Math.max(1.5, 17 * Math.abs(Math.cos(phase * Math.PI * 2)));
  const moonIsWaxing = phase < 0.5;
  const showSun = !isNight && (kind === "clear" || kind === "partly-cloudy");
  const showMoon = isNight;

  return (
    <div className={`weather-scene scene-${dayPart}`} aria-label={`${kind} weather illustration`}>
      {isNight && (
        <div className="scene-stars" aria-hidden="true">
          {Array.from({ length: 28 }, (_, i) => (
            <span key={i} style={{ left: `${(i * 37 + 11) % 97}%`, top: `${(i * 23 + 7) % 78}%`, animationDelay: `${(i % 7) * 0.35}s` }} />
          ))}
        </div>
      )}
      <svg className="weather-art" viewBox="0 0 260 190" role="img" aria-hidden="true">
        <defs>
          <linearGradient id="sunFill" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#fff4b0" />
            <stop offset="100%" stopColor="#ffb547" />
          </linearGradient>
          <linearGradient id="cloudFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="100%" stopColor={isNight ? "#9eafc9" : "#cbd8e8"} />
          </linearGradient>
          <clipPath id="moonClip"><circle cx="188" cy="55" r="25" /></clipPath>
        </defs>

        {showSun && (
          <g className="sun-motion">
            <circle cx="72" cy="66" r="39" fill="#ffc857" opacity=".16" />
            <circle cx="72" cy="66" r="25" fill="url(#sunFill)" />
            {Array.from({ length: 8 }, (_, i) => (
              <line key={i} x1="72" y1="29" x2="72" y2="19" stroke="#ffd36c" strokeWidth="3" strokeLinecap="round" transform={`rotate(${i * 45} 72 66)`} />
            ))}
          </g>
        )}

        {showMoon && (
          <g className="moon-motion">
            <circle cx="188" cy="55" r="35" fill="#dce8ff" opacity=".09" />
            <circle cx="188" cy="55" r="25" fill="#f5edc9" />
            <g clipPath="url(#moonClip)">
              <ellipse
                cx={188 + (moonIsWaxing ? -moonDarkX : moonDarkX)}
                cy="55"
                rx={moonDarkRx}
                ry="27"
                fill="#263650"
                opacity=".88"
              />
            </g>
            {phase > 0.46 && phase < 0.54 && <circle cx="188" cy="55" r="25" fill="#fff4c8" />}
          </g>
        )}

        {(kind === "partly-cloudy" || kind === "cloudy" || kind === "rain" || kind === "snow" || kind === "storm" || kind === "fog" || kind === "wind") && (
          <g className="cloud-motion">
            <path
              d="M54 130c-16 0-28-11-28-25 0-13 10-23 23-25 5-20 22-33 43-33 22 0 40 15 44 36 17 1 30 13 30 29 0 10-7 18-17 18H54z"
              fill="url(#cloudFill)"
              stroke={isNight ? "#c8d7ef" : "#ffffff"}
              strokeWidth="2"
            />
            <path d="M52 125c8 7 20 8 32 8h65" fill="none" stroke={isNight ? "#8296b6" : "#aebfd2"} strokeWidth="2" opacity=".55" />
          </g>
        )}

        {(kind === "rain" || kind === "storm") && (
          <g className="rain-motion" stroke="#9bdcff" strokeWidth="4" strokeLinecap="round">
            <path d="M64 145l-7 15M91 145l-7 15M119 145l-7 15M146 145l-7 15" />
          </g>
        )}
        {kind === "storm" && (
          <path className="lightning-motion" d="M117 139l-12 24h13l-5 20 24-30h-14l8-14z" fill="#ffe36e" stroke="#fff2a8" strokeWidth="1.5" />
        )}
        {kind === "snow" && (
          <g className="snow-motion" fill="#eaf7ff">
            <circle cx="62" cy="154" r="4" /><circle cx="91" cy="169" r="3.5" /><circle cx="124" cy="154" r="4" /><circle cx="151" cy="171" r="3" />
            <path d="M62 145v18m-7-9h14m-12-5l10 10m0-10l-10 10M124 145v18m-7-9h14" stroke="#eaf7ff" strokeWidth="1.5" />
          </g>
        )}
        {kind === "fog" && (
          <g className="fog-motion" stroke="#e8f0f8" strokeWidth="5" strokeLinecap="round" opacity=".8">
            <path d="M35 145h150M55 158h130M25 171h155" />
          </g>
        )}
        {kind === "wind" && (
          <g className="wind-motion" fill="none" stroke="#d9ecff" strokeWidth="3" strokeLinecap="round">
            <path d="M25 151h75q14 0 14-10t-14-9M40 165h112q14 0 14-10t-14-9" />
          </g>
        )}
      </svg>
      <div className="scene-caption">{isNight ? "Moonlit sky" : dayPart === "afternoon" ? "Afternoon sky" : "Daytime sky"}</div>
    </div>
  );
}

function WeatherIndex() {
  const [weather, setWeather] = useState<WeatherState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [timeStr, setTimeStr] = useState("");
  const [dayPart, setDayPart] = useState<DayPart>(getDayPart);

  useEffect(() => {
    const updateTime = () => {
      setTimeStr(new Intl.DateTimeFormat("en-IN", {
        timeZone: "Asia/Kolkata",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
      }).format(new Date()));
      setDayPart(getDayPart());
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    let active = true;
    async function loadWeather() {
      try {
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${CAMPUS.lat}&longitude=${CAMPUS.lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,surface_pressure,wind_speed_10m&hourly=uv_index,visibility,precipitation_probability,temperature_2m,weather_code&forecast_days=2&timezone=Asia%2FKolkata`;
        const res = await fetch(url);
        if (!res.ok) throw new Error("Weather service unreachable");
        const data = await res.json();
        if (!active) return;
        const cur = data.current;
        const code = Number(cur.weather_code);
        const { kind, desc } = describeWeather(code);
        const currentTime = new Date(cur.time).getTime();
        const hourlyTimes: string[] = data.hourly?.time ?? [];
        const startIndex = Math.max(0, hourlyTimes.findIndex((time) => new Date(time).getTime() > currentTime));
        const forecast: HourForecast[] = hourlyTimes.slice(startIndex, startIndex + 6).map((time: string, index: number) => ({
          time,
          temp: Math.round(data.hourly.temperature_2m[startIndex + index]),
          code: Number(data.hourly.weather_code[startIndex + index]),
        }));

        setWeather({
          temp: Math.round(cur.temperature_2m),
          feels: Math.round(cur.apparent_temperature),
          code,
          isDay: cur.is_day === 1,
          wind: Math.round(cur.wind_speed_10m),
          humidity: Math.round(cur.relative_humidity_2m),
          pressure: Math.round(cur.surface_pressure),
          uv: Math.round(data.hourly?.uv_index?.[0] ?? 0),
          visibility: Math.round((data.hourly?.visibility?.[0] ?? 10000) / 1000),
          precipProb: Math.round(data.hourly?.precipitation_probability?.[0] ?? 0),
          desc,
          kind,
          dayPart: getDayPart(),
          forecast,
        });
        setError(null);
      } catch (err) {
        if (active) setError(err instanceof Error ? err.message : "Failed to load weather");
      }
    }
    loadWeather();
    const refresh = setInterval(loadWeather, 10 * 60 * 1000);
    return () => {
      active = false;
      clearInterval(refresh);
    };
  }, []);

  const background = useMemo(() => {
    if (dayPart === "night") return "from-[#071426] via-[#142744] to-[#253b5c]";
    if (dayPart === "afternoon") return "from-[#e58a45] via-[#eeb66b] to-[#7e9fc1]";
    return "from-[#4d9bd0] via-[#83c4e8] to-[#d5e9f3]";
  }, [dayPart]);

  const forecastTime = (value: string) =>
    new Date(value).toLocaleTimeString("en-IN", {
      timeZone: "Asia/Kolkata",
      hour: "numeric",
      hour12: true,
    });

  return (
    <div className={`weather-dashboard fixed inset-0 overflow-auto text-white bg-gradient-to-br ${background} transition-all duration-1000 flex flex-col justify-between p-5 md:p-8 select-none`}>
      <div className="ambient-glow" aria-hidden="true" />
      <header className="relative z-10 flex items-center justify-between gap-4">
        <div className="flex items-center gap-2 font-semibold tracking-wider text-sm md:text-base">
          <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          LIVE WEATHER
        </div>
        <div className="text-right">
          <div className="text-xl md:text-2xl font-light tracking-wide">{timeStr}</div>
          <div className="text-xs text-white/70">Local Time (IST)</div>
        </div>
      </header>

      <main className="relative z-10 my-auto grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-8 items-center max-w-5xl mx-auto w-full py-5">
        <div>
          <div className="text-xs font-mono tracking-widest text-white/80 uppercase">{CAMPUS.area}</div>
          <h1 className="text-6xl md:text-8xl font-light tracking-tight my-2">{weather ? `${weather.temp}°` : "--°"}</h1>
          <h2 className="text-2xl md:text-3xl font-light text-white/90">{weather?.desc || (error ? "Report Unavailable" : "Reading the sky…")}</h2>
          <p className="text-sm md:text-base text-white/75 mt-3 max-w-md">
            {CAMPUS.name}. Feels like {weather ? `${weather.feels}°C` : "--"} with {weather ? `${weather.humidity}%` : "--"} humidity.
          </p>
          {error && <p className="text-sm text-red-100 mt-3">{error}</p>}
        </div>

        <div className="min-w-0">
          <WeatherScene kind={weather?.kind ?? "clear"} dayPart={dayPart} />
          <div className="grid grid-cols-2 gap-3 md:gap-4 mt-3">
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-4">
              <span className="text-xs text-white/70 uppercase">Wind</span>
              <div className="text-xl md:text-2xl font-light mt-1">{weather ? `${weather.wind} km/h` : "--"}</div>
            </div>
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-4">
              <span className="text-xs text-white/70 uppercase">Humidity</span>
              <div className="text-xl md:text-2xl font-light mt-1">{weather ? `${weather.humidity}%` : "--"}</div>
            </div>
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-4">
              <span className="text-xs text-white/70 uppercase">Rain Chance</span>
              <div className="text-xl md:text-2xl font-light mt-1">{weather ? `${weather.precipProb}%` : "--"}</div>
            </div>
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-4">
              <span className="text-xs text-white/70 uppercase">UV Index</span>
              <div className="text-xl md:text-2xl font-light mt-1">{weather ? `${weather.uv} of 11` : "--"}</div>
            </div>
          </div>
        </div>

        {weather?.forecast?.length ? (
          <section className="md:col-span-2 mt-2">
            <div className="text-xs tracking-widest uppercase text-white/75 mb-3">Upcoming hourly forecast</div>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {weather.forecast.map((item) => {
                const forecastWeather = describeWeather(item.code);
                return (
                  <div key={item.time} className="rounded-xl border border-white/15 bg-white/10 backdrop-blur-md px-2 py-3 text-center">
                    <div className="text-xs text-white/70">{forecastTime(item.time)}</div>
                    <div className="text-sm mt-2">{forecastWeather.desc}</div>
                    <div className="text-xl font-light mt-1">{item.temp}°</div>
                  </div>
                );
              })}
            </div>
          </section>
        ) : null}
      </main>

      <footer className="relative z-10 flex items-center justify-between text-xs text-white/60 gap-3">
        <span>Chanakya University • Devanahalli Campus</span>
        <span>Auto-updates every 10 min</span>
      </footer>
    </div>
  );
}
